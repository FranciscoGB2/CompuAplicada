#!/bin/bash

origen=""
destino=""

mostrar_ayuda () {
	echo "uso de backup_full.sh: -o directorio_de_origen -d directorio_destino"
	echo "-o directorio de origen"
	echo "-d directorio de destino ((donde se guardan los datos))"
	echo "-h muestra la ayuda"
	exit 1

}

fecha=$(date "+%Y%m%d")
tiempo=$(date "+%H:%M:%S")

log_mensaje(){
	local mensaje="$1"
	echo "$fecha - $tiempo - $mensaje" >> "/var/log/backup_full.log"
}

while getopts "o:d:h" opt; do
	case $opt in
	o) origen="$OPTARG";;
	d) destino="$OPTARG";;
	h) mostrar_ayuda;;
	\?) echo "opcion incorrecta" >&2; exit 1;;
	esac
done

if [ -z "$origen" ] || [ -z "$destino" ];then
	echo "se debe especificar un directorio de origen y uno de destino"
	mostrar_ayuda
fi

if [ ! -d "$origen" ] || [ ! -d "$destino" ]; then
	echo "los directorios no exiten o quiza no estan montados"
	exit 1
fi

nombre_archivo="$(basename $origen)_bkp_${fecha}.tar.gz"

log_mensaje "solicitud de backup recibida para $origen guardando en $destino"
tar czf "${destino}/${nombre_archivo}" "$origen" && log_mensaje "backup exitoso" || log_mensaje "error al hacer el backup"
echo "este es el archivo" | mutt -s "archivo log" -a /var/log/backup_full.log -- root
