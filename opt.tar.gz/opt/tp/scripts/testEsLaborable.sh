#!/bin/bash

source esLaborable.sh

esFeriado "2023-11-06"
esFeriado "2023-01-01"
esFeriado "2023-12-25"
esFeriado "2023-03-23"
esFeriado "2023-03-24"
